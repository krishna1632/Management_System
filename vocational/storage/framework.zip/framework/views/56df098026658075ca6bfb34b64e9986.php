<nav class="sb-sidenav accordion sb-sidenav-light" id="sidenavAccordion">
    <div class="sb-sidenav-menu">
        <div class="nav">

            <a class="nav-link" href="<?php echo e(url('admin/dashboard')); ?>">
                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                Dashboard
            </a>

            <a class="nav-link" href="<?php echo e(url('/admin/faculty')); ?>">
                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                Faculty
            </a>


            <div class="sb-sidenav-menu-heading"> Study Mast</div>
            <a class="nav-link" href="<?php echo e(url('admin/upload_pyq')); ?>">
                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                Upload PYQ
            </a>
            <a class="nav-link" href="<?php echo e(url('admin/study_materials')); ?>">
                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                Study Materials
            </a>
            <a class="nav-link" href="<?php echo e(url('#')); ?>">
                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                RoadMaps
            </a>
            <a class="nav-link" href="<?php echo e(url('#')); ?>">
                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                Syllabus
            </a>



            <div class="sb-sidenav-menu-heading">More Actions</div>
            <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseSocieties"
                aria-expanded="false" aria-controls="collapseSocieties">
                <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                Quiz Mast
                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
            </a>
            <div class="collapse" id="collapseSocieties" aria-labelledby="headingOne"
                data-bs-parent="#sidenavAccordion">
                <nav class="sb-sidenav-menu-nested nav">
                    <a class="nav-link" href="<?php echo e(url('#')); ?>">Create Quiz</a>
                    <a class="nav-link" href="<?php echo e(url('#')); ?>">Create Quiz Repoarts</a>
                </nav>
            </div>

            

            




        </div>
    </div>

</nav>
<?php /**PATH C:\xampp\htdocs\Management_System\vocational\resources\views/layouts/partials/sidebar.blade.php ENDPATH**/ ?>