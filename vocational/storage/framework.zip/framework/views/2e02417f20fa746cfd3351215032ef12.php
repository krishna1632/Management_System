<?php $__env->startSection('title', 'Faculty Management'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="mt-4">Faculty Management</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="<?php echo e(url('/admin/dashboard')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item active">Faculty</li>
    </ol>

    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-table me-1"></i>
            Faculty List
            <a href="<?php echo e(route('admin.faculty.create')); ?>" class="btn btn-primary btn-sm float-end">Add Faculty</a>
        </div>
        <div class="card-body">
            <table id="datatablesSimple" class="table table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Department</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $faculties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faculty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($faculty->id); ?></td>
                            <td><?php echo e($faculty->name); ?></td>
                            <td><?php echo e($faculty->email); ?></td>
                            <td><?php echo e($faculty->phone); ?></td>
                            <td><?php echo e($faculty->department); ?></td>
                            <td>
                                <a href="<?php echo e(route('admin.faculty.show', $faculty->id)); ?>" class="btn btn-info btn-sm">View</a>
                                <a href="<?php echo e(route('admin.faculty.edit', $faculty->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                                <form action="<?php echo e(route('admin.faculty.destroy', $faculty->id)); ?>" method="POST" style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this faculty?')">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Management_System\vocational\resources\views/admin/faculty/index.blade.php ENDPATH**/ ?>